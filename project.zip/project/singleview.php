<html>
	<head>
		<title>Single View</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="gallery.css">
		<link rel="stylesheet" type="text/css" href="admin.css">
		<link rel="stylesheet" type="text/css" href="singleview.css">
		<script src="gallery.js"></script>
		<script src="singleview.js"></script>
	</head>
	
	<body>	
	
		<div class="header">
			<div class="topnav">
				<a class="active" href="admin.php">Home</a>
				<a href="gallery.php">Gallery</a>
				<a href="customer.php">About</a>
				<a class="tablinks" onclick="openTab(event, 'Log_in')">Log in</a>
				<a class="tablinks" onclick="openTab(event, 'Register')">Register</a>
			</div>
		</div>

		
		<div id="Log_in" class="logtab" >
			<div class="col-12">
				<form target="_blank" method="get" id="product_detail">
					<table>
					<tr>
						<td>Email :<br><br></td>
						<td>
							<input type="email" name="pEmail" style="width: 200px;"><br><br>
						</td>
					</tr>
					<tr>
						<td>Password :<br><br></td>
						<td>
							<input type="password" name="pPassword" style="width: 200px;"><br><br>
						</td>
					</tr>
					<tr>
						<td colspan="2">
							<input type="submit" value="Log In" class="navbutton">
							<input type="reset" value="Cancel" style="margin-left: 20px;" class="navbutton" onclick="closeTab(event,'Log_in')">
						</td>
					</tr>
					</table>
				</form> 
			</div>
		</div>
		
		<div id="Register" class="regtab" >
			<div class="col-12">
				<form target="_blank" method="get" id="product_detail">
					<table>
					<tr>
						<td>Name :<br><br></td>
						<td>
							<input type="text" name="pName" style="width: 200px;"><br><br>
						</td>
					</tr>
					<tr>
						<td>Email :<br><br></td>
						<td>
							<input type="email" name="pEmail" style="width: 200px;"><br><br>
						</td>
					</tr>
					<tr>
						<td>Mobile Phone :<br><br></td>
						<td>
							<input type="text" name="pMobile" style="width: 200px;"><br><br>
						</td>
					</tr>
					<tr>
						<td>Password :<br><br></td>
						<td>
							<input type="password" name="pPassword" style="width: 200px;"><br><br>
						</td>
					</tr>
					<tr>
						<td>Confirm Password :<br><br></td>
						<td>
							<input type="password" name="pCPassword" style="width: 200px;"><br><br>
						</td>
					</tr>
					<tr>
						<td colspan="2">
							<input type="submit" value="Log In" class="navbutton">
							<input type="reset" value="Cancel" style="margin-left: 20px;" class="navbutton" onclick="closeTab(event,'Register')">
						</td>
					</tr>
					</table>
				</form> 
			</div>
		</div>
		
		
		<div class="row">
			<div class="boxleft col-4">
				<p>----Name----</p><br>
				<p>----by----</p>
				<p>----price----</p>
				<p>----comment----</p>
				<p>----Fabric specification----</p>
				<p>----type----</p>
			</div>
			
			
			<div class="col-4">
				<div class="img-zoom-container">
					<?php
						echo '<img id="myimage" src="img/'.$_GET["id"].'.jpg" class="singleimg">';
					?>
				</div>
				<div class="boxbottom col-4">
					<b>Choose Tshirt Color:</b>
				</div>
			</div>
			
			
			<div class="boxleft col-4" style="overflow-x:auto;">
				<img class="sizeimg" src="img/size.png">
				<div id="myresult" class="img-zoom-result"></div>
				<table class="forTable" align="center">
					<tr>
						<th id="t1">Size</th><th id="t1">Length</th><th id="t1">Width</th><th id="t1">Sleeve</th>
					</tr>
					<tr>
						<th id="t1">S</th><td id="t1">68 cm (26.77″)</td><td id="t1">48 cm (18.9″)</td><td id="t1">20 cm (7.87″)</td>
					</tr>
					<tr>
						<th id="t1">M</th><td id="t1">70 cm (27.56″)</td><td id="t1">50 cm (19.69″)</td><td id="t1">21 cm (8.27″)</td>
					</tr>
					<tr>
						<th id="t1">L</th><td id="t1">72 cm (28.35″)</td><td id="t1">52 cm (20.47″)</td><td id="t1">22 cm (8.66″)</td>
					</tr>
					<tr>
						<th id="t1">XL</th><td id="t1">74 cm (29.13″)</td><td id="t1">55 cm (21.65″)</td><td id="t1">23 cm (9.06″)</td>
					</tr>
					<tr>
						<th id="t1">XXL</th><td id="t1">76 cm (29.92″)</td><td id="t1">58 cm (22.83″)</td><td id="t1">24 cm (9.45″)</td>
					</tr>
					<tr>
						<th id="t1">3XL</th><td id="t1">78 cm (30.71″)</td><td id="t1">61 cm (24.02″)</td><td id="t1">25 cm (9.84″)</td>
					</tr>
					<tr>
						<th id="t1">4XL</th><td id="t1">80 cm (31.5″)</td><td id="t1">64 cm (25.2″)	</td><td id="t1">26 cm (10.24″)</td>
					</tr>
				</table>
			</div>
		</div>
		<script>
			// Initiate zoom effect:
			imageZoom("myimage", "myresult");
		</script>
	</body>
</html>